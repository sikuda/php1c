<?php 
require_once( 'php1C_common.php');

$REZULTAT = null;
function SLOZHENIE($D,$YA){
$REZULTAT=php1C\add1C(php1C\add1C("4",$D),$YA);
}
SLOZHENIE(1,2);

 ?>